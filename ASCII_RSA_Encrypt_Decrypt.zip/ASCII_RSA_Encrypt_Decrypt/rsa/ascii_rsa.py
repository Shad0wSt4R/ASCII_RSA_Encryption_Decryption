__author__ = 'marlenahochmuth'
#ENCRYPT C = M^e % (p*q)
#DECRYPT M = C^d % (p*q)

#will find a number that is relatively prime to (p - 1)(q - 1)
def findEncryptionKey(P, Q):
    n = (P - 1)*(Q - 1)
    i = 100
    while(not(n % i == 1)):
        i += 1
        #print(i)
    return i

def divisionAlgorithm(a, d):
    r = a
    q = 0
    while(r >= d):
        r -= d
        q += 1
        #print(q)
    return q

def findDecryptionKey(P, Q, E):
    n = (P - 1)*(Q - 1)
    quotient = divisionAlgorithm(n, E)
    quotient *= (-1)
    d = n + quotient
    print(d)
    return d

print("Welcome to the RSA Encryption program!\n")

prime1 = input("Please enter the first prime:\n")
prime2 = input("Please enter the second prime:\n")

message = input("Please enter the message you would like to encrypt:\n" )

cipherText = ""
#alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
#alphaEncode = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]
#p = 929
#q = 1667
p = int(prime1)
q = int(prime2)
e = findEncryptionKey(p, q)
print(e)

#want to cycle through message and find letter in alphabet array
#and the corresponding index in alphaEncode
for l in message:
    M = ord(l)
    print(M)
    C = (M**e) % (p*q)
    cipherText += str(C)
    cipherText += " "

print(cipherText)

option = input("Would you like to decrypt this message?(YES or NO)\n")

if(option.upper() == "YES"):
    d = findDecryptionKey(p, q, e)
    decryptedMessage = ""
    n = ""
    for digit in cipherText:
        if(digit != " "):
            n += digit
        else:
            C = int(n)
            M = (C**d) % (p*q)
            print(chr(M))
            decryptedMessage += chr(M)
            n = ""
    print(decryptedMessage)
